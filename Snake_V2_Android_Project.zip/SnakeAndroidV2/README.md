# Snake V2.0
Unbranded neon arcade Snake for Android. Includes persistent best score, pause/resume, four difficulty modes, unlockable color skins, sound effects, audio settings and neon visuals.
