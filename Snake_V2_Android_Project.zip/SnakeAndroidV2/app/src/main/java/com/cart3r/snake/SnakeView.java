package com.cart3r.snake;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.BlurMaskFilter;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

public class SnakeView extends View {
 private final int BG=0xFF05070D,PANEL=0xFF101827,GRID=0xFF1A2A3D,WHITE=0xFFF2F7FF,MUTED=0xFF8FA3B8,RED=0xFFFF456A,CYAN=0xFF35E8FF;
 private final int[] skins={0xFF42FF9E,0xFF35E8FF,0xFFFF4FD8,0xFFFFC857,0xFFAA83FF};
 private final String[] skinNames={"MINT","CYAN","PINK","GOLD","VIOLET"};
 private final Paint p=new Paint(3); private final Handler handler=new Handler(Looper.getMainLooper()); private final Random rng=new Random(); private final SharedPreferences prefs;
 private final ArrayList<Cell> body=new ArrayList<>(); private ToneGenerator tones;
 private int cols,rows,cell,score,best,dx=1,dy=0,mode=1,skin=0; private Cell food;
 private boolean started=false,over=false,paused=false,settings=false,sound=true,music=true; private float downX,downY; private long lastStep; private int musicNote=0;
 private final Runnable musicLoop=new Runnable(){public void run(){if(music&&tones!=null&&!settings){int[] notes={ToneGenerator.TONE_DTMF_1,ToneGenerator.TONE_DTMF_3,ToneGenerator.TONE_DTMF_5,ToneGenerator.TONE_DTMF_3};tones.startTone(notes[musicNote++%notes.length],110);}handler.postDelayed(this,520);}};
 private static class Cell{int x,y;Cell(int a,int b){x=a;y=b;}}
 public SnakeView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);prefs=c.getSharedPreferences("snake_v2",0);best=prefs.getInt("best",0);mode=prefs.getInt("mode",1);skin=prefs.getInt("skin",0);sound=prefs.getBoolean("sound",true);music=prefs.getBoolean("music",true);try{tones=new ToneGenerator(AudioManager.STREAM_MUSIC,65);}catch(Exception ignored){}reset();handler.post(tick);handler.postDelayed(musicLoop,500);}
 private final Runnable tick=new Runnable(){public void run(){if(started&&!over&&!paused&&getWidth()>0){int[] speeds={205,145,105,72};if(System.currentTimeMillis()-lastStep>=Math.max(55,speeds[mode]-score/50*5)){step();lastStep=System.currentTimeMillis();}}invalidate();handler.postDelayed(this,16);}};
 private void tone(int t,int ms){if(sound&&tones!=null)tones.startTone(t,ms);}
 private void reset(){body.clear();int x=Math.max(4,cols/2),y=Math.max(4,rows/2);body.add(new Cell(x,y));body.add(new Cell(x-1,y));body.add(new Cell(x-2,y));dx=1;dy=0;score=0;started=false;over=false;paused=false;spawn();invalidate();}
 private void spawn(){if(cols<2||rows<2)return;for(int n=0;n<1000;n++){Cell f=new Cell(rng.nextInt(cols),rng.nextInt(rows));boolean used=false;for(Cell b:body)if(b.x==f.x&&b.y==f.y){used=true;break;}if(!used){food=f;return;}}}
 private void step(){Cell h=body.get(0),n=new Cell(h.x+dx,h.y+dy);boolean eat=food!=null&&n.x==food.x&&n.y==food.y;int count=eat?body.size():body.size()-1;if(n.x<0||n.y<0||n.x>=cols||n.y>=rows){over=true;tone(ToneGenerator.TONE_PROP_NACK,350);save();return;}for(int i=0;i<count;i++){Cell b=body.get(i);if(b.x==n.x&&b.y==n.y){over=true;tone(ToneGenerator.TONE_PROP_NACK,350);save();return;}}body.add(0,n);if(eat){score+=10;tone(ToneGenerator.TONE_PROP_BEEP,90);if(score>best){best=score;save();}spawn();}else body.remove(body.size()-1);}
 private void save(){prefs.edit().putInt("best",best).apply();}
 @Override protected void onSizeChanged(int w,int h,int ow,int oh){cell=Math.max(12,Math.min(w/22,(h-230)/27));cols=Math.max(8,w/cell);rows=Math.max(8,(h-230)/cell);reset();}
 private void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){p.setColor(color);p.setTextSize(size);p.setFakeBoldText(bold);p.setTextAlign(align);p.setStyle(Paint.Style.FILL);p.setMaskFilter(null);c.drawText(s,x,y,p);}
 private void button(Canvas c,String label,float x,float y,float w,float h,boolean active){p.setMaskFilter(null);p.setColor(active?0xFF123447:0xFF182336);p.setStyle(Paint.Style.FILL);RectF r=new RectF(x,y,x+w,y+h);c.drawRoundRect(r,16,16,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(active?CYAN:0xFF354B64);c.drawRoundRect(r,16,16,p);p.setStyle(Paint.Style.FILL);txt(c,label,x+w/2,y+h/2+5,14,active?CYAN:WHITE,true,Paint.Align.CENTER);}
 @Override protected void onDraw(Canvas c){c.drawColor(BG);float w=getWidth(),h=getHeight();txt(c,"S N A K E",w/2,48,25,CYAN,true,Paint.Align.CENTER);txt(c,"NEON ARCADE",w/2,70,10,MUTED,false,Paint.Align.CENTER);if(settings){drawSettings(c,w);return;}if(!started||over||paused){drawMenu(c,w,h);return;}drawGame(c,w,h);}
 private void drawMenu(Canvas c,float w,float h){txt(c,over?"GAME OVER":paused?"PAUSED":"READY?",w/2,h*.25f,29,over?RED:CYAN,true,Paint.Align.CENTER);txt(c,"SCORE  "+score+"     BEST  "+best,w/2,h*.25f+34,15,WHITE,true,Paint.Align.CENTER);float bw=w*.72f,bx=(w-bw)/2,bh=52,y=h*.39f;button(c,over?"PLAY AGAIN":paused?"RESUME":"START GAME",bx,y,bw,bh,true);button(c,"DIFFICULTY: "+new String[]{"EASY","NORMAL","HARD","INSANE"}[mode],bx,y+68,bw,bh,false);button(c,"SKIN: "+skinNames[skin],bx,y+136,bw,bh,false);button(c,"SETTINGS",bx,y+204,bw,bh,false);if(!over&&!paused)txt(c,"SWIPE TO STEER DURING PLAY",w/2,y+292,11,MUTED,false,Paint.Align.CENTER);}
 private void drawSettings(Canvas c,float w){txt(c,"SETTINGS",w/2,125,25,CYAN,true,Paint.Align.CENTER);float bw=w*.72f,bx=(w-bw)/2,y=190;button(c,"SOUND EFFECTS: "+(sound?"ON":"OFF"),bx,y,bw,55,sound);button(c,"BACKGROUND MUSIC: "+(music?"ON":"OFF"),bx,y+75,bw,55,music);button(c,"BACK",bx,y+165,bw,55,true);txt(c,"BEST SCORE  "+best,w/2,y+270,14,MUTED,false,Paint.Align.CENTER);}
 private void drawGame(Canvas c,float w,float h){float left=(w-cols*cell)/2f,top=105;RectF board=new RectF(left-5,top-5,left+cols*cell+5,top+rows*cell+5);p.setMaskFilter(null);p.setColor(PANEL);c.drawRoundRect(board,16,16,p);p.setColor(GRID);p.setStrokeWidth(1);for(int x=0;x<=cols;x++)c.drawLine(left+x*cell,top,left+x*cell,top+rows*cell,p);for(int y=0;y<=rows;y++)c.drawLine(left,top+y*cell,left+cols*cell,top+y*cell,p);txt(c,"SCORE "+score,24,91,16,WHITE,true,Paint.Align.LEFT);txt(c,"BEST "+best,w-24,91,14,MUTED,true,Paint.Align.RIGHT);if(food!=null){p.setColor(RED);p.setMaskFilter(new BlurMaskFilter(12,BlurMaskFilter.Blur.NORMAL));c.drawCircle(left+(food.x+.5f)*cell,top+(food.y+.5f)*cell,cell*.35f,p);p.setMaskFilter(null);}for(int i=body.size()-1;i>=0;i--){Cell b=body.get(i);p.setColor(i==0?WHITE:skins[skin]);p.setMaskFilter(i==0?new BlurMaskFilter(10,BlurMaskFilter.Blur.NORMAL):null);RectF r=new RectF(left+b.x*cell+2,top+b.y*cell+2,left+(b.x+1)*cell-2,top+(b.y+1)*cell-2);c.drawRoundRect(r,cell*.25f,cell*.25f,p);}p.setMaskFilter(null);button(c,"Ⅱ  PAUSE",w*.34f,h-62,w*.32f,44,true);}
 @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;return true;}if(e.getAction()!=MotionEvent.ACTION_UP)return true;float sx=x-downX,sy=y-downY;if(started&&!over&&!paused&&!settings){if(Math.abs(sx)<18&&Math.abs(sy)<18&&y>h-90){paused=true;invalidate();return true;}if(Math.abs(sx)>Math.abs(sy)){if(sx>0&&dx!=-1){dx=1;dy=0;}else if(sx<0&&dx!=1){dx=-1;dy=0;}}else{if(sy>0&&dy!=-1){dx=0;dy=1;}else if(sy<0&&dy!=1){dx=0;dy=-1;}}return true;}if(settings){float base=190;if(y>base&&y<base+55){sound=!sound;prefs.edit().putBoolean("sound",sound).apply();}else if(y>base+75&&y<base+130){music=!music;prefs.edit().putBoolean("music",music).apply();}else if(y>base+165&&y<base+220)settings=false;invalidate();return true;}float y0=h*.39f;if(y>y0&&y<y0+58){if(paused)paused=false;else{reset();started=true;lastStep=System.currentTimeMillis();}}else if(y>y0+68&&y<y0+124){mode=(mode+1)%4;prefs.edit().putInt("mode",mode).apply();}else if(y>y0+136&&y<y0+192){int max=best>=300?5:best>=150?4:best>=60?3:2;skin=(skin+1)%max;prefs.edit().putInt("skin",skin).apply();}else if(y>y0+204&&y<y0+260)settings=true;invalidate();return true;}
 @Override protected void onDetachedFromWindow(){handler.removeCallbacks(tick);if(tones!=null)tones.release();handler.removeCallbacks(musicLoop);super.onDetachedFromWindow();}
}
