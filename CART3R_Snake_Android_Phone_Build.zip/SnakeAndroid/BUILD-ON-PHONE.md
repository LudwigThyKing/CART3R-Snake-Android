# Build the APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
GitHub's hosted runner builds the APK; Android Studio or a PC is not required.

1. Sign in to GitHub in your phone browser and create a **public or private repository**.
2. Upload the contents of this project, keeping the `SnakeAndroid/` folder and the `.github/workflows/` folder at the repository root. GitHub's website may require uploading the extracted files rather than the ZIP itself. Enable **Show hidden files** so `.github` is included.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** in the workflow list, tap **Run workflow**, then confirm.
5. Wait for the workflow to finish successfully. Open the completed run and download the `CART3R-Snake-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your phone, tap `app-debug.apk`, and allow installation from your browser or file manager if Android asks.

The APK is a debug-signed APK intended for personal testing/sideloading. Do not share signing keys or repository secrets; none are needed for this build.
