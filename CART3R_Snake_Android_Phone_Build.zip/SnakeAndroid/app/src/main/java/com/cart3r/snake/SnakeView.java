package com.cart3r.snake;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Random;

public class SnakeView extends View {
    private static final int BG = 0xFF080808, GREEN = 0xFF39F078,
            RED = 0xFFFF3030, WHITE = 0xFFF5F5F5, MUTED = 0xFF999999,
            PANEL = 0xFF151515, GRID = 0xFF171717;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final ArrayList<Cell> snake = new ArrayList<>();
    private int cols, rows, score, best, dx = 1, dy = 0, cell;
    private Cell food;
    private boolean gameOver = false, started = false;
    private float downX, downY;
    private long lastStep;

    private static class Cell { int x, y; Cell(int x, int y) { this.x=x; this.y=y; } }

    public SnakeView(Context context) {
        super(context);
        setFocusable(true);
        reset();
        handler.post(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (started && !gameOver && getWidth() > 0) {
                long now = System.currentTimeMillis();
                int interval = Math.max(75, 155 - score / 50 * 8);
                if (now - lastStep >= interval) { step(); lastStep = now; }
            }
            invalidate();
            handler.postDelayed(this, 16);
        }
    };

    private void reset() {
        snake.clear();
        int cx = Math.max(4, cols / 2), cy = Math.max(4, rows / 2);
        snake.add(new Cell(cx, cy)); snake.add(new Cell(cx - 1, cy)); snake.add(new Cell(cx - 2, cy));
        dx = 1; dy = 0; score = 0; gameOver = false; started = false;
        placeFood(); lastStep = System.currentTimeMillis(); invalidate();
    }

    private void placeFood() {
        if (cols < 2 || rows < 2) return;
        for (int tries = 0; tries < 1000; tries++) {
            Cell c = new Cell(random.nextInt(cols), random.nextInt(rows));
            boolean occupied = false;
            for (Cell s : snake) if (s.x == c.x && s.y == c.y) { occupied = true; break; }
            if (!occupied) { food = c; return; }
        }
    }

    private void step() {
        Cell h = snake.get(0);
        Cell next = new Cell(h.x + dx, h.y + dy);
        boolean eating = food != null && next.x == food.x && next.y == food.y;
        int bodyCount = eating ? snake.size() : snake.size() - 1;
        if (next.x < 0 || next.y < 0 || next.x >= cols || next.y >= rows) { gameOver = true; return; }
        for (int i = 0; i < bodyCount; i++) {
            Cell b = snake.get(i);
            if (b.x == next.x && b.y == next.y) { gameOver = true; return; }
        }
        snake.add(0, next);
        if (eating) { score += 10; best = Math.max(best, score); placeFood(); }
        else snake.remove(snake.size() - 1);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        cell = Math.max(12, Math.min(w / 22, (h - 190) / 30));
        cols = Math.max(8, w / cell);
        rows = Math.max(8, (h - 170) / cell);
        reset();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(BG);
        float w = getWidth();
        p.setColor(RED); p.setTextSize(28); p.setFakeBoldText(true);
        c.drawText("CART3R", 24, 48, p);
        p.setColor(MUTED); p.setTextSize(11); p.setFakeBoldText(false);
        c.drawText("S N A K E   /   A R C A D E", 26, 69, p);
        p.setColor(WHITE); p.setTextSize(18); p.setFakeBoldText(true);
        c.drawText("SCORE  " + score, 24, 112, p);
        p.setColor(MUTED); p.setTextSize(14); p.setFakeBoldText(false);
        c.drawText("BEST  " + best, w - 110, 111, p);

        float left = (w - cols * cell) / 2f;
        float top = 145;
        RectF board = new RectF(left - 5, top - 5, left + cols * cell + 5, top + rows * cell + 5);
        p.setColor(PANEL); c.drawRoundRect(board, 18, 18, p);
        p.setColor(GRID); p.setStrokeWidth(1);
        for (int x=0; x<=cols; x++) c.drawLine(left+x*cell, top, left+x*cell, top+rows*cell, p);
        for (int y=0; y<=rows; y++) c.drawLine(left, top+y*cell, left+cols*cell, top+y*cell, p);

        if (food != null) {
            p.setColor(RED); c.drawCircle(left+(food.x+.5f)*cell, top+(food.y+.5f)*cell, cell*.36f, p);
        }
        for (int i=snake.size()-1; i>=0; i--) {
            Cell s=snake.get(i); float inset=i==0?2:3;
            p.setColor(i==0?0xFF8CFFB0:GREEN);
            RectF r=new RectF(left+s.x*cell+inset, top+s.y*cell+inset,
                    left+(s.x+1)*cell-inset, top+(s.y+1)*cell-inset);
            c.drawRoundRect(r, cell*.22f, cell*.22f, p);
        }
        p.setColor(MUTED); p.setTextSize(13); p.setTextAlign(Paint.Align.CENTER);
        c.drawText("SWIPE ANYWHERE TO CONTROL", w/2, top+rows*cell+38, p);
        p.setTextAlign(Paint.Align.LEFT);
        if (!started || gameOver) {
            p.setColor(0xDD000000); c.drawRoundRect(board,18,18,p);
            p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true);
            p.setColor(gameOver?RED:GREEN); p.setTextSize(27);
            c.drawText(gameOver?"GAME OVER":"SNAKE", w/2, top+rows*cell/2f-10, p);
            p.setColor(WHITE); p.setTextSize(15); p.setFakeBoldText(false);
            c.drawText(gameOver?"Tap to play again":"Swipe to start", w/2, top+rows*cell/2f+22, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) { downX=e.getX(); downY=e.getY(); return true; }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float x=e.getX()-downX, y=e.getY()-downY;
            if (!started || gameOver) { reset(); started=true; lastStep=System.currentTimeMillis(); invalidate(); return true; }
            if (Math.abs(x) > Math.abs(y)) {
                if (x > 20 && dx != -1) { dx=1; dy=0; }
                else if (x < -20 && dx != 1) { dx=-1; dy=0; }
            } else {
                if (y > 20 && dy != -1) { dx=0; dy=1; }
                else if (y < -20 && dy != 1) { dx=0; dy=-1; }
            }
            return true;
        }
        return true;
    }

    @Override protected void onDetachedFromWindow() { handler.removeCallbacks(tick); super.onDetachedFromWindow(); }
}
