# CART3R Snake — Android project

Native Android implementation of the Snake game. It uses Java and a custom Canvas view; no third-party game engine or runtime permissions are required.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version.
2. Open this folder (`SnakeAndroid`) in Android Studio and allow Gradle sync to finish.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio creates the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer that APK to your phone and open it to install. If prompted, allow your file manager/browser to install unknown apps.

The app targets portrait mode and supports swipe controls. Tap the board to start or restart.
